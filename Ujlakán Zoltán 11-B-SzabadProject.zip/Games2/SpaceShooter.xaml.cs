﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Windows.Threading;

namespace Games2
{
    /// <summary>
    /// Interaction logic for SpaceShooter.xaml
    /// </summary>
    public partial class SpaceShooter : Window
    {
        DispatcherTimer gameTimer = new DispatcherTimer();
        bool balra, jobbra;
        List<Rectangle> itemRemover = new List<Rectangle>();
        Random r = new Random();

        int enemyspritecounter = 0;
        int enemycounter = 100;
        int playerspeed = 12;
        int limit = 50;
        int score = 0;
        int damage = 0;
        int enemyspeed = 10;

        Rect PlayerHitBox;

        public SpaceShooter()
        {
            InitializeComponent();

            gameTimer.Interval = TimeSpan.FromMilliseconds(20);
            gameTimer.Tick += GameLoop;
            gameTimer.Start();
            MyCanvas.Focus();
            ImageBrush bg = new ImageBrush();
            bg.ImageSource = new BitmapImage(new Uri("pack://application:,,,/Images/black.png"));
            bg.TileMode = TileMode.Tile;
            bg.Viewport = new Rect(0, 0, 0.15, 0.15);
            bg.ViewportUnits = BrushMappingMode.RelativeToBoundingBox;
            MyCanvas.Background = bg;
            ImageBrush playerImage = new ImageBrush();
            playerImage.ImageSource = new BitmapImage(new Uri("pack://application:,,,/Images/player.png"));
            player.Fill = playerImage;
        }

        private void GameLoop(object sender, EventArgs e)
        {
            PlayerHitBox = new Rect(Canvas.GetLeft(player), Canvas.GetTop(player), player.Width, player.Height);

            enemycounter -= 1;

            scoreText.Content = "Pontszám: " + score;
            damageText.Content = "Kapott sebzés: " + damage;

            if (enemycounter < 0)
            {
                MakeEnemies();
                enemycounter = limit;
            }

            if (balra == true && Canvas.GetLeft(player) > 0) //Irányítás <-- -->
            {
                Canvas.SetLeft(player, Canvas.GetLeft(player) - playerspeed);
            }
            if (jobbra == true && Canvas.GetLeft(player) + 90 < Application.Current.MainWindow.Width)
            {
                Canvas.SetLeft(player, Canvas.GetLeft(player) + playerspeed);
            }


            foreach (var x in MyCanvas.Children.OfType<Rectangle>())
            {
                if (x is Rectangle && (string)x.Tag == "shot")
                {
                    Canvas.SetTop(x, Canvas.GetTop(x) - 20);

                    Rect bulletHitBox = new Rect(Canvas.GetLeft(x), Canvas.GetTop(x), x.Width, x.Height);

                    if (Canvas.GetTop(x) < 10)
                    {
                        itemRemover.Add(x);
                    }

                    foreach (var y in MyCanvas.Children.OfType<Rectangle>())
                    {
                        if (y is Rectangle && (string)y.Tag == "enemy")
                        {
                            Rect enemyHit = new Rect(Canvas.GetLeft(y), Canvas.GetTop(y), y.Width, y.Height);

                            if (bulletHitBox.IntersectsWith(enemyHit))
                            {
                                itemRemover.Add(x);
                                itemRemover.Add(y);
                                score++;
                            }
                        }
                    }

                }

                if (x is Rectangle && (string)x.Tag == "enemy")
                {
                    Canvas.SetTop(x, Canvas.GetTop(x) + enemyspeed);

                    if (Canvas.GetTop(x) > 750)
                    {
                        itemRemover.Add(x);
                        damage += 10;
                    }

                    Rect enemyHitBox = new Rect(Canvas.GetLeft(x), Canvas.GetTop(x), x.Width, x.Height);

                    if (PlayerHitBox.IntersectsWith(enemyHitBox))
                    {
                        itemRemover.Add(x);
                        damage += 5;
                    }

                }
            }

            foreach (Rectangle i in itemRemover)
            {
                MyCanvas.Children.Remove(i);
            }


            if (score > 5)
            {
                limit = 20;
                enemyspeed = 15;
            }

            if (damage > 99)
            {
                gameTimer.Stop();
                damageText.Content = "Kapott sebzés: 100";
                damageText.Foreground = Brushes.Red;
                if(MessageBox.Show("Kilőtt ellenségek száma: " + score + Environment.NewLine + "Még egy kör?", "Vége a játéknak!", MessageBoxButton.YesNo)==MessageBoxResult.Yes)
                {
                    SpaceShooter sW = new SpaceShooter();
                    sW.Show();
                    this.Close();
                }
                else
                {
                    System.Diagnostics.Process.Start(Application.ResourceAssembly.Location);
                    Application.Current.Shutdown();
                }
            }
        }

        private void OnKeyDown(object sender, KeyEventArgs e)
        {
            if(e.Key == Key.Left)
            {
                balra = true;
            }
            if (e.Key == Key.Right)
            {
                jobbra = true;
            }

            if (e.Key == Key.A)
            {
                balra = true;
            }
            if (e.Key == Key.D)
            {
                jobbra = true;
            }
        }

        private void OnKeyUp(object sender, KeyEventArgs e)
        {
            if (e.Key == Key.Left)
            {
                balra = false;
            }
            if (e.Key == Key.Right)
            {
                jobbra = false;
            }

            if (e.Key == Key.A)
            {
                balra = false;
            }
            if (e.Key == Key.D)
            {
                jobbra = false;
            }

            if (e.Key == Key.Space) //Lövés
            {
                Rectangle newShot = new Rectangle
                {
                    Tag = "shot",
                    Height = 20,
                    Width = 5,
                    Fill = Brushes.White,
                    Stroke = Brushes.Red
                };

                Canvas.SetLeft(newShot, Canvas.GetLeft(player) + player.Width / 2);
                Canvas.SetTop(newShot, Canvas.GetTop(player) - newShot.Height);

                MyCanvas.Children.Add(newShot);
            }
        }

        private void MakeEnemies()
        {
            ImageBrush enemySprite = new ImageBrush();
            enemyspritecounter = r.Next(1, 5);
            switch (enemyspritecounter)
            {
                case 1:
                    enemySprite.ImageSource = new BitmapImage(new Uri("pack://application:,,,/Images/1.png"));
                    break;
                case 2:
                    enemySprite.ImageSource = new BitmapImage(new Uri("pack://application:,,,/Images/2.png"));
                    break;
                case 3:
                    enemySprite.ImageSource = new BitmapImage(new Uri("pack://application:,,,/Images/3.png"));
                    break;
                case 4:
                    enemySprite.ImageSource = new BitmapImage(new Uri("pack://application:,,,/Images/4.png"));
                    break;
                case 5:
                    enemySprite.ImageSource = new BitmapImage(new Uri("pack://application:,,,/Images/5.png"));
                    break;
            }

            Rectangle newEnemy = new Rectangle
            {
                Tag = "enemy",
                Height = 50,
                Width = 56,
                Fill = enemySprite
            };

            Canvas.SetTop(newEnemy, -100);
            Canvas.SetLeft(newEnemy, r.Next(30, 430));

            MyCanvas.Children.Add(newEnemy);
        }
    }
}
