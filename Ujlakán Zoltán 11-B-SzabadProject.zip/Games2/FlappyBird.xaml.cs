﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Windows.Threading;

namespace Games2
{
    /// <summary>
    /// Interaction logic for FlappyBird.xaml
    /// </summary>
    public partial class FlappyBird : Window
    {
        DispatcherTimer gameTimer = new DispatcherTimer();

        double score;
        int gravity = 8;
        bool gameOver;
        Rect BirdHitBox;

        public FlappyBird()
        {
            InitializeComponent();

            gameTimer.Tick += MainEventTimer;
            gameTimer.Interval = TimeSpan.FromMilliseconds(20);
            StartGame();
        }

        private void MainEventTimer(object sender, EventArgs e)
        {
            scoreText3.Content = "Pontszám: " + score;

            BirdHitBox = new Rect(Canvas.GetLeft(Bird), Canvas.GetTop(Bird), Bird.Width - 12, Bird.Height);

            Canvas.SetTop(Bird, Canvas.GetTop(Bird) + gravity);

            if (Canvas.GetTop(Bird) < -30 || Canvas.GetTop(Bird) + Bird.Height > 460)
            {
                EndGame();
            }


            foreach (var x in MyCanvas3.Children.OfType<Image>())
            {
                if ((string)x.Tag == "oszlop1" || (string)x.Tag == "oszlop2" || (string)x.Tag == "oszlop3")
                {
                    Canvas.SetLeft(x, Canvas.GetLeft(x) - 5);

                    if (Canvas.GetLeft(x) < -100)
                    {
                        Canvas.SetLeft(x, 800);

                        score += .5;
                    }

                    Rect PillarHitBox = new Rect(Canvas.GetLeft(x), Canvas.GetTop(x), x.Width, x.Height);

                    if (BirdHitBox.IntersectsWith(PillarHitBox))
                    {
                        EndGame();
                    }
                }

                if ((string)x.Tag == "clouds")
                {
                    Canvas.SetLeft(x, Canvas.GetLeft(x) - 1);

                    if (Canvas.GetLeft(x) < -250)
                    {
                        Canvas.SetLeft(x, 550);

                        score += .5;
                    }
                }
            }
        }

        private void KeyIsDown(object sender, KeyEventArgs e)
        {
            if (e.Key == Key.Space)
            {
                Bird.RenderTransform = new RotateTransform(-20, Bird.Width / 2, Bird.Height / 2);
                gravity = -8;
            }

            if (e.Key == Key.R && gameOver == true)
            {
                StartGame();
            }
        }

        private void KeyIsUp(object sender, KeyEventArgs e)
        {
            Bird.RenderTransform = new RotateTransform(5, Bird.Width / 2, Bird.Height / 2);

            gravity = 8;
        }

        private void StartGame()
        {
            MyCanvas3.Focus();

            int temp = 300;

            score = 0;

            gameOver = false;

            Canvas.SetTop(Bird, 190);

            foreach (var x in MyCanvas3.Children.OfType<Image>())
            {
                if ((string)x.Tag == "oszlop1")
                {
                    Canvas.SetLeft(x, 500);
                }
                if ((string)x.Tag == "oszlop2")
                {
                    Canvas.SetLeft(x, 800);
                }
                if ((string)x.Tag == "oszlop3")
                {
                    Canvas.SetLeft(x, 1100);
                }

                if ((string)x.Tag == "clouds")
                {
                    Canvas.SetLeft(x, 300 + temp);
                    temp = 800;
                }
            }

            gameTimer.Start();
        }

        private void EndGame()
        {
            gameTimer.Stop();
            gameOver = true;
            if (MessageBox.Show("Elért pontszám: " + score + Environment.NewLine + "Még egy kör?", "Vége a játéknak!", MessageBoxButton.YesNo) == MessageBoxResult.Yes)
            {
                FlappyBird sW = new FlappyBird();
                sW.Show();
                this.Close();
            }
            else
            {
                System.Diagnostics.Process.Start(Application.ResourceAssembly.Location);
                Application.Current.Shutdown();
            }

        }
    }
}
