﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Windows.Threading;

namespace Games2
{
    /// <summary>
    /// Interaction logic for EndlessRunner.xaml
    /// </summary>
    public partial class EndlessRunner : Window
    {
        DispatcherTimer gameTimer = new DispatcherTimer();

        Rect playerHitBox;
        Rect groundHitBox;
        Rect oszlopHitBox;

        bool jump;
        int force = 20;
        int speed = 5;

        Random r = new Random();

        bool gameOver;
        double spriteIndex = 0;

        ImageBrush playerSprite = new ImageBrush();
        ImageBrush backgroundSprite = new ImageBrush();
        ImageBrush oszlopSprite = new ImageBrush();

        int[] oszlopPosition = { 320, 310, 300, 305, 315 };

        int score = 0;

        public EndlessRunner()
        {
            InitializeComponent();

            MyCanvas2.Focus();

            gameTimer.Tick += GameEngine;
            gameTimer.Interval = TimeSpan.FromMilliseconds(20);

            backgroundSprite.ImageSource = new BitmapImage(new Uri("pack://application:,,,/Images/background2.gif"));

            background.Fill = backgroundSprite;
            background2.Fill = backgroundSprite;

            StartGame();
        }

        private void GameEngine(object sender, EventArgs e)
        {

            Canvas.SetLeft(background, Canvas.GetLeft(background) - 3);
            Canvas.SetLeft(background2, Canvas.GetLeft(background2) - 3);

            if (Canvas.GetLeft(background) < -1262)
            {
                Canvas.SetLeft(background, Canvas.GetLeft(background2) + background2.Width);
            }

            if (Canvas.GetLeft(background2) < -1262)
            {
                Canvas.SetLeft(background2, Canvas.GetLeft(background) + background.Width);
            }

            Canvas.SetTop(player, Canvas.GetTop(player) + speed);
            Canvas.SetLeft(oszlop, Canvas.GetLeft(oszlop) - 12);

            scoreText2.Content = "Pontszám: " + score;

            playerHitBox = new Rect(Canvas.GetLeft(player), Canvas.GetTop(player), player.Width - 15, player.Height);
            oszlopHitBox = new Rect(Canvas.GetLeft(oszlop), Canvas.GetTop(oszlop), oszlop.Width, oszlop.Height);
            groundHitBox = new Rect(Canvas.GetLeft(ground), Canvas.GetTop(ground), ground.Width, ground.Height);

            if (playerHitBox.IntersectsWith(groundHitBox))
            {
                speed = 0;

                Canvas.SetTop(player, Canvas.GetTop(ground) - player.Height);

                jump = false;

                spriteIndex += .5;

                if (spriteIndex > 8)
                {
                    spriteIndex = 1;
                }

                RunSprite(spriteIndex);

            }

            if (jump == true)
            {
                speed = -9;

                force -= 1;
            }
            else
            {
                speed = 12;
            }

            if (force < 0)
            {
                jump = false;
            }

            if (Canvas.GetLeft(oszlop) < -50)
            {
                Canvas.SetLeft(oszlop, 950);

                Canvas.SetTop(oszlop, oszlopPosition[r.Next(0, oszlopPosition.Length)]);

                score += 1;
            }

            if (playerHitBox.IntersectsWith(oszlopHitBox))
            {
                gameOver = true;
                gameTimer.Stop();
            }

            if (gameOver == true)
            {
                oszlop.Stroke = Brushes.Black;
                oszlop.StrokeThickness = 1;

                player.Stroke = Brushes.Red;
                player.StrokeThickness = 1;

                if (MessageBox.Show("Elért pontszám: " + score + Environment.NewLine + "Még egy kör?", "Vége a játéknak!", MessageBoxButton.YesNo) == MessageBoxResult.Yes)
                {
                    EndlessRunner sW = new EndlessRunner();
                    sW.Show();
                    this.Close();
                }
                else
                {
                    System.Diagnostics.Process.Start(Application.ResourceAssembly.Location);
                    Application.Current.Shutdown();
                }
            }
            else
            {
                player.StrokeThickness = 0;
                oszlop.StrokeThickness = 0;
            }
        }

        private void KeyIsDown(object sender, KeyEventArgs e)
        {
            
        }

        private void KeyIsUp(object sender, KeyEventArgs e)
        {
            if (e.Key == Key.Space && jump == false && Canvas.GetTop(player) > 260)
            {
                jump = true;
                force = 15;
                speed = -12;

                playerSprite.ImageSource = new BitmapImage(new Uri("pack://application:,,,/Images/newRunner_02.gif"));
            }
        }

        private void StartGame()
        {
            Canvas.SetLeft(background, 0);
            Canvas.SetLeft(background2, 1262);

            Canvas.SetLeft(player, 110);
            Canvas.SetTop(player, 140);

            Canvas.SetLeft(oszlop, 950);
            Canvas.SetTop(oszlop, 310);

            RunSprite(1);

            oszlopSprite.ImageSource = new BitmapImage(new Uri("pack://application:,,,/Images/obstacle2.png"));
            oszlop.Fill = oszlopSprite;

            jump = false;
            gameOver = false;
            score = 0;

            scoreText2.Content = "Pontszám: " + score;

            gameTimer.Start();

        }

        private void RunSprite(double i)
        {

            switch (i) //Képek beállítása -> "futás illúzió"
            {
                case 1:
                    playerSprite.ImageSource = new BitmapImage(new Uri("pack://application:,,,/Images/newRunner_01.gif"));
                    break;
                case 2:
                    playerSprite.ImageSource = new BitmapImage(new Uri("pack://application:,,,/Images/newRunner_02.gif"));
                    break;
                case 3:
                    playerSprite.ImageSource = new BitmapImage(new Uri("pack://application:,,,/Images/newRunner_03.gif"));
                    break;
                case 4:
                    playerSprite.ImageSource = new BitmapImage(new Uri("pack://application:,,,/Images/newRunner_04.gif"));
                    break;
                case 5:
                    playerSprite.ImageSource = new BitmapImage(new Uri("pack://application:,,,/Images/newRunner_05.gif"));
                    break;
                case 6:
                    playerSprite.ImageSource = new BitmapImage(new Uri("pack://application:,,,/Images/newRunner_06.gif"));
                    break;
                case 7:
                    playerSprite.ImageSource = new BitmapImage(new Uri("pack://application:,,,/Images/newRunner_07.gif"));
                    break;
                case 8:
                    playerSprite.ImageSource = new BitmapImage(new Uri("pack://application:,,,/Images/newRunner_08.gif"));
                    break;
            }

            player.Fill = playerSprite;
        }
    }
}
