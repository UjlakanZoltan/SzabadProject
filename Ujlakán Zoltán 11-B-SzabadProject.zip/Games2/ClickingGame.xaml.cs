﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Windows.Threading;

namespace Games2
{
    /// <summary>
    /// Interaction logic for ClickingGame.xaml
    /// </summary>
    public partial class ClickingGame : Window
    {
        DispatcherTimer gameTimer = new DispatcherTimer();  //Időzítő létrehozása.

        List<Ellipse> removeThis = new List<Ellipse>(); //Lista létrehozása (a körök eltünteséhet kell!)

        int spawnRate = 60; //Alapértelmezett megjelenítési érték.
        int currentRate; //Aktuális érték -> a kör tágulása. 
        int health = 350; 
        int positionX; 
        int positionY; 
        int score = 0; 

        double growthRate = 0.6;  //Alapértelmezett növekedési érték.

        Random r = new Random(); 
        Brush brush; //Szín a körökhöz.

        public ClickingGame()
        {
            InitializeComponent();

            gameTimer.Tick += GameLoop; 
            gameTimer.Interval = TimeSpan.FromMilliseconds(20); //Időzítő, 20ms-enként lejátszódik.
            gameTimer.Start(); 

            currentRate = spawnRate; // Beállítja az aktuális spwanrate-et. 
        }

        private void GameLoop(object sender, EventArgs e) //Minden alkalommal lefut amikor az időzítő lejár.
        {
            txtScore6.Content = "Pontszám: " + score;;
            currentRate -= 2;

            if (currentRate < 1)
            { //A körök legenerálása: Hely és szín (zöld).
                currentRate = spawnRate;
                positionX = r.Next(15, 700);
                positionY = r.Next(50, 350);
                brush = new SolidColorBrush(Color.FromRgb(0, 255, 0));

                Ellipse bubble = new Ellipse
                {
                    Tag = "bubble",
                    Height = 10,
                    Width = 10,
                    Stroke = Brushes.Black,
                    StrokeThickness = 1,
                    Fill = brush
                };

                Canvas.SetLeft(bubble, positionX);
                Canvas.SetTop(bubble, positionY);
                MyCanvas6.Children.Add(bubble); //Hozzáadja kört a Canvas-hez.
            }

            foreach (var x in MyCanvas6.Children.OfType<Ellipse>()) //Meg kell keresni egy létező kört a Canvas-ben és növelni az értékét 70-ig, utána eltűnik.
            {
                x.Height += growthRate; 
                x.Width += growthRate; 
                x.RenderTransformOrigin = new Point(0.5, 0.5); 

                if (x.Width > 70)
                {
                    removeThis.Add(x); //Ha eléri a kör értéke a 70-et, utána eltűnik és 15-tel csökken a HP.
                    health -= 15; 
                }

            } 

            if (health > 1)
            {
                HealthBar.Width = health;
            }
            else
            {
                GameOver();
            }

            foreach (Ellipse i in removeThis)
            {
                MyCanvas6.Children.Remove(i); 
            }

            if (score > 5) //Játékmenet gyorsítása.
            {
                spawnRate = 25;
            }
 
            if (score > 20)
            {
                spawnRate = 15;
                growthRate = 1.5;
            }
        }

        private void ClickOnCanvas(object sender, MouseButtonEventArgs e)
        {
            if (e.OriginalSource is Ellipse)
            {
                Ellipse bubble = (Ellipse)e.OriginalSource;

                MyCanvas6.Children.Remove(bubble);

                score++;
            }
        }

        private void GameOver()
        {
            gameTimer.Stop();

            if (MessageBox.Show("Elért pontszám: " + score + Environment.NewLine + "Még egy kör?", "Vége a játéknak!", MessageBoxButton.YesNo) == MessageBoxResult.Yes)
            {
                ClickingGame sW = new ClickingGame();
                sW.Show();
                this.Close();
            }
            else
            {
                System.Diagnostics.Process.Start(Application.ResourceAssembly.Location);
                Application.Current.Shutdown();
            }

            foreach (var y in MyCanvas6.Children.OfType<Ellipse>())
            {
                removeThis.Add(y);
            }
            foreach (Ellipse i in removeThis)
            {
                MyCanvas6.Children.Remove(i);
            }
            //Értékek visszaállítása. 
            growthRate = .6;
            spawnRate = 60;
            score = 0;
            currentRate = 5;
            health = 350;
            removeThis.Clear();

        }
    }
}
